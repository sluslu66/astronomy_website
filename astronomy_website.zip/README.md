# 🌌 Astronomy Explorer

Simple astronomy-themed website project.

## Features
- Responsive layout
- Interactive button
- Simple UI with HTML, CSS, JS

## How to Run
Just open index.html in your browser.

## Author
Created for GitHub project upload.
