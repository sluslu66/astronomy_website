function showMessage() {
    alert("🚀 Let's explore the universe!");
}
